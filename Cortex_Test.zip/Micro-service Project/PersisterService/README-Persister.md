/--------------***--------------/
 Title: Cortex Test - Persister Microservice
 Description: This microservice call parser microservice to take parsed json object and store into SQL server database and return true or false.
 Author: Nisha Fadadu
 Date: 9th Sept 2017
/------------****-------------/