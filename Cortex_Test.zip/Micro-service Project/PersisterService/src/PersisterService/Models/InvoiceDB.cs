﻿using Microsoft.Extensions.Configuration;
using System;
using System.Data.SqlClient;
using PersisterService;
using System.Linq;
using System.Collections.Generic;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : InvoiceDB class 
 * Description : insert method for Invoice Object
 * Date : 10th Sept 2017
 * 
 **/
namespace PersisterService.Models
{
    public class InvoiceDB
    {
        //insert invoices
        public bool insertInvoice(Invoice inv) 
        {
            // prepare connection
            SqlConnection connection = DBHelper.getDBConnection();
            // prepare the statement
            string insertString = "insert into Invoice " +
                                  "(documentType, documentNumber, date, amount,currency) " +
                                  "values(@documentType, @documentNumber, @date, @amount, @currency)";
            SqlCommand insertCommand = new SqlCommand(insertString, connection);
            insertCommand.Parameters.AddWithValue("@documentType", inv.documentType);
            insertCommand.Parameters.AddWithValue("@documentNumber", inv.documentNumber);
            insertCommand.Parameters.AddWithValue("@date", inv.date);
            insertCommand.Parameters.AddWithValue("@amount", inv.amount);
            insertCommand.Parameters.AddWithValue("@currency", inv.currency);
            try
            {
                // open connection
                connection.Open();

                // execute the statement
                insertCommand.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
               connection.Close(); //close connection
            }
           
        } //end of insert invoice

         

        public bool InvoiceExist(string documentNumber)
        {
            bool result = false;
            SqlConnection connection = DBHelper.getDBConnection(); //get connection
            string selectStatement = "SELECT * " +
                                    "From Invoice " +
                                    "where documentNumber = @documentNumber";  //sql query
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@documentNumber", documentNumber);
            try
            {
                connection.Open();
                SqlDataReader Reader = selectCommand.ExecuteReader(); //execute query
                while (Reader.Read()) //order exists
                {
                    result = true;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close(); //close connection
            }
            return result;
        }
    }
}
