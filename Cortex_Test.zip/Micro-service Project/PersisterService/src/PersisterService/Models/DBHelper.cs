﻿using Microsoft.Extensions.Configuration;
using System;
using System.Data.SqlClient;
using PersisterService;
using System.Linq;
using System.Collections.Generic;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : DBHelper class 
 * Description : Get Database connection
 * Date : 10th Sept 2017
 * 
 **/
namespace PersisterService.Models
{
    public class DBHelper
    {
        public static SqlConnection getDBConnection()
        {
            string connectionString = @"Data Source=ICTVM-4V7OPVIN3\SQLEXPRESS;Initial Catalog=Cortext_Test;Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

    }
}
