﻿using System;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Invoice class 
 * Description : invoice class properties
 * Date : 10th Sept 2017
 * 
 **/

namespace PersisterService.Models
{
    public class Invoice
    {
        //properties
        public string date;
        public string amount;
        public string currency;
        public string documentNumber;
        public string documentType;
    }
}