﻿/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Response class 
 * Description : response class properties
 * Date : 10th Sept 2017
 * 
 **/
namespace PersisterService.Models
{
    public class Response
    {
        //properties
        public string documentType;
        public string documentNumber;
        public string originalDocumentNumber;
        public string status;
        public string date;
        public string amount;
        public string currency;
        
    }
}