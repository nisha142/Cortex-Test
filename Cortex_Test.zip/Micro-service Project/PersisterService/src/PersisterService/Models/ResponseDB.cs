﻿using System;
using System.Data.SqlClient;
using Microsoft.Extensions;
using Microsoft.Extensions.Configuration;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : ResponseDB class 
 * Description : insert method for Response Object
 * Date : 10th Sept 2017
 * 
 **/
namespace PersisterService.Models
{
    public class ResponseDB
    {
        //insert response
        public bool insertResponse(Response res) 
        {
            // prepare connection

            SqlConnection connection = DBHelper.getDBConnection();
            // prepare the statement
            string insertString = "insert into Response " +
                                  "(documentType, documentNumber, originalDocumentNumber, status, date, amount,currency) " +
                                  "values(@documentType, @documentNumber, @originalDocumentNumber, @status, @date, @amount, @currency)";
            SqlCommand insertCommand = new SqlCommand(insertString, connection);
            insertCommand.Parameters.AddWithValue("@documentType", res.documentType);
            insertCommand.Parameters.AddWithValue("@documentNumber", res.documentNumber);
            insertCommand.Parameters.AddWithValue("@originalDocumentNumber", res.originalDocumentNumber);
            insertCommand.Parameters.AddWithValue("@status", res.status);
            insertCommand.Parameters.AddWithValue("@date", res.date);
            insertCommand.Parameters.AddWithValue("@amount", res.amount);
            insertCommand.Parameters.AddWithValue("@currency", res.currency);
            try
            {
                // open connection
                connection.Open();

                // execute the statement
                insertCommand.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
               connection.Close(); //close connection
            }
           
        } //end of insert response

        public bool responseExist(string documentNumber)
        {
            bool result = false;
            SqlConnection connection = DBHelper.getDBConnection();
            string selectStatement = "SELECT * " +
                                    "From Response " +
                                    "where documentNumber = @documentNumber";  //sql query
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@documentNumber", documentNumber);
            try
            {
                connection.Open();
                SqlDataReader Reader = selectCommand.ExecuteReader(); //execute query
                while (Reader.Read()) //order exists
                {
                    result = true;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close(); //close connection
            }
            return result;
        }
    }
}
