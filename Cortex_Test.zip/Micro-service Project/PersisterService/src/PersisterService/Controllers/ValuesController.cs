﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PersisterService.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Persister Microservice 
 * Description : PersisterService is take Invoice and Response list objects from parser microservice 
 *              and store into SQL Database and return boolean value
 * Date : 10th Sept 2017
 * 
 **/

namespace PersisterService.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        // GET api/values
        [HttpGet]
        public string Get()
        {
            return "Persister service has been started.";
        }
        // POST api/values
        [HttpPost]
        public async Task<int> Post()
        {
            int i = 0;
            List<Response> responseList = new List<Response>(); //response list 
            List<Invoice> invoiceList = new List<Invoice>(); //invoice list
            try
            {
                using (var client = new HttpClient()) //call parser service via httpclient
                {
                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST parser service resources (Invoice and Response) using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("http://localhost:65183/api/values/ParsedData");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        try
                        {
                            //Storing the response details recieved from web api   
                            var inputObj = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Order list  
                            var OrderInfo = JsonConvert.DeserializeObject<Tuple<List<Response>, List<Invoice>>>(inputObj);
                            //get Invoice and Response list from response
                            responseList = OrderInfo.Item1;
                            invoiceList = OrderInfo.Item2;
                            //insert Response object and Invoice object into SQL database
                            InvoiceDB invoice = new InvoiceDB();
                            ResponseDB responses = new ResponseDB();

                            foreach (Invoice inv in invoiceList)
                            {
                                if (!invoice.InvoiceExist(inv.documentNumber))
                                    invoice.insertInvoice(inv); //call insert invoice object method
                            }
                            foreach (Response res in responseList)
                            {
                                if (!responses.responseExist(res.documentNumber))
                                    responses.insertResponse(res); //call insert response object method
                            }

                        }
                        catch (Exception)
                        {
                            return 1; // Unable to Store Invoice and Response Data into Database!
                        }
                        return 0; // Parsed Invoice and Response Data Successfully Added To Database!
                    }
                    else { return 3; } // Something wrong with collector service!s

                }
            }

            catch (Exception)
            {
                return 2; // Something wrong with parser service!
            }
        }
    } //end of get method
}

