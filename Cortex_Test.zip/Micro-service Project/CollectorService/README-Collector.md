/--------------***--------------/
 Title: Cortex Test - Collector Microservice
 Description: This microservice read json file and return json object. The input.json file is 	placed inside this service's project folder.
 Author: Nisha Fadadu
 Date: 9th Sept 2017
/------------****-------------/