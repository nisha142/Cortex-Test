﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
/* 
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Collector Microservice 
 * Description : CollectorService is reading json data from input.json file and return object
 * Date : 10th Sept 2017
 * */
namespace CollectorService.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        // GET api/values
        [HttpGet]
        public string Get()
        {
            return "Collecter service has been started.";
        }

        // GET api/values
        [HttpGet("ReadFile")]
        public object ReadFile()
        {
            try
            {
                //read json file
                string allText = System.IO.File.ReadAllText(@"~\..\input.json");
                object jsonObject = JsonConvert.DeserializeObject(allText); //convert into json object
                return jsonObject;
            }
            catch (Exception ex)
            {
                throw ex; // Unable to Read json file!
            }

        }
    }
}
