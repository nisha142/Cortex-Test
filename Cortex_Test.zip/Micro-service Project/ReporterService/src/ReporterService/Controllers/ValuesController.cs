﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ReporterService.Models;
using System.Net.Http;
using System.Net.Http.Headers;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Reporter Microservice 
 * Description : ReporterService is fatching data from database or it will call to persister microservice 
 *              and generate final report
 * Date : 10th Sept 2017
 * 
 **/

namespace ReporterService.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        // GET api/values
        [HttpGet]
        public string Get()
        {
            return "Reporter service has been started.";
        }

        // GET api/values
        [HttpGet("ReportSchema")]
        public async Task<List<Report>> ReportSchema()
        {
            List<Invoice> inv = ReportDB.GetInvoice(); //call GetInvoice method 
            List<Response> res = ReportDB.GetResponse(); //call GetResponse method
            List<Report> report = new List<Report>(); //instantiate Report List Object 

            try
            {
                if (inv.Count == 0 || res.Count == 0) //if their is no data in database
                {

                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        StringContent queryString = new StringContent("");
                        //Sending request to find web api REST service resource using HttpClient  
                        HttpResponseMessage Res = await client.PostAsync("http://localhost:3198/api/values", queryString);

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var inputObj = Res.Content.ReadAsStringAsync().Result;
                        }
                    }
                    inv = ReportDB.GetInvoice(); //call GetInvoice method 
                    res = ReportDB.GetResponse(); //call GetResponse method
                }

                foreach (Invoice inv1 in inv)
                {
                    //get invoice with related response list
                    Report rep = new Report();
                    rep.original = inv1;
                    rep.responses = res.Where(i => i.originalDocumentNumber == inv1.documentNumber).ToList();
                    report.Add(rep); //add to report object
                }

                foreach (Response res1 in res)
                {
                    //get Response which has no related Invoice
                    Report rep = new Report();
                    rep.responses = new List<Response>();
                    if (inv.Where(i => i.documentNumber == res1.originalDocumentNumber).Count() == 0)
                    {
                        rep.responses.Add(res1);
                        report.Add(rep); //add to report object
                    }
                }
                return report; //return final report object
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
