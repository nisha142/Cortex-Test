﻿using System;
using System.Collections.Generic;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Invoice class 
 * Description : Invoice class properties
 * Date : 10th Sept 2017
 * 
 **/

namespace ReporterService.Models
{
    public class Invoice
    {
        //define properties
        public string documentType;
        public string documentNumber;
        public string date;
        public string amount;
        public string currency;
                      
    }
}