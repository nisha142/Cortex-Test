﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : ReportDB class 
 * Description : GetInvoice and GetResponse method to get list of objects 
 * Date : 10th Sept 2017
 * 
 **/

namespace ReporterService.Models
{
    public class ReportDB
    {
        //get invoice list from database
        public static List<Invoice> GetInvoice()
        {
            List<Invoice> inv = new List<Invoice>(); //creates empty invoice list

            SqlConnection connection = DBHelper.getDBConnection(); //get connection
            string selectStatement = "SELECT * "
                                   + "FROM Invoice";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Invoice nextInv = new Invoice();
                    nextInv.documentType = reader["documentType"].ToString();
                    nextInv.documentNumber = reader["documentNumber"].ToString();
                    nextInv.date = reader["date"].ToString();
                    nextInv.amount = reader["amount"].ToString();
                    nextInv.currency = reader["currency"].ToString();
                    inv.Add(nextInv);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return inv; //return Invoice list
        }

        //get response list from database
        public static List<Response> GetResponse()
        {
                        List<Response> res = new List<Response>(); //create empty response list

            SqlConnection connection = DBHelper.getDBConnection(); //get connection
            string selectStatement = "SELECT * "
                                   + "FROM Response Order by date desc";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open(); //open connection
                SqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    Response nextRes = new Response();
                    nextRes.documentType = reader["documentType"].ToString();
                    nextRes.documentNumber = reader["documentNumber"].ToString();
                    nextRes.date = reader["date"].ToString();
                    nextRes.amount = reader["amount"].ToString();
                    nextRes.currency = reader["currency"].ToString();
                    nextRes.originalDocumentNumber = reader["originalDocumentNumber"].ToString();
                    nextRes.status = reader["status"].ToString();
                    res.Add(nextRes);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return res; //return Response List
        }
    }
}
