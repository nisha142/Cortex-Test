﻿using System;
using System.Collections.Generic;
/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Report class 
 * Description : Report class properties
 * Date : 10th Sept 2017
 * 
 **/

namespace ReporterService.Models
{
    public class Report
    {
        //define properties
        public Invoice original;
        public List<Response> responses;
              
    }
}