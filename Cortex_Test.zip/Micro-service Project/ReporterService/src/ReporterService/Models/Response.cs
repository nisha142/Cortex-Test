﻿/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Response class 
 * Description : Response class properties
 * Date : 10th Sept 2017
 * 
 **/
namespace ReporterService.Models
{
    public class Response
    {
        //define properties
        public string documentType;
        public string documentNumber;
        public string originalDocumentNumber;
        public string status;
        public string date;
        public string amount;
        public string currency;
        
    }
}