﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : DBHelper class 
 * Description : Get Database connection
 * Date : 10th Sept 2017
 * 
 **/

namespace ReporterService.Models
{
    public class DBHelper
    {
        public static SqlConnection getDBConnection()
        {
            //change this connection string to connect with your SQL Server
            string connectionString = @"Data Source=ICTVM-4V7OPVIN3\SQLEXPRESS;Initial Catalog=Cortext_Test;Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

    }
}