/--------------***--------------/
 Title: Cortex Test - Reporter Microservice
 Description: This microservice check database for report data, if their is no data in database then it will call persister microservice and tell it to store data into database. Then it will generate report-schema.json output.
 Author: Nisha Fadadu
 Date: 9th Sept 2017
/------------****-------------/