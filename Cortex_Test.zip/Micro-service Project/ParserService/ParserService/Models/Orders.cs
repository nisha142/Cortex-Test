﻿using System;
/* *
* Author: Nisha Fadadu
* Cortex Test Project
* Titel : Orders class
* Description : defines orders properties 
* Date : 10th Sept 2017
* 
**/
namespace ParserService.Models
{
    public class Orders
    {
        //input object properties
        public string responseNumber;
        public string originalInvoiceNumber;
        public string status;
        public DateTime date;
        public string amount;
        public string currency;
        public string invoiceNumber;
    }
}