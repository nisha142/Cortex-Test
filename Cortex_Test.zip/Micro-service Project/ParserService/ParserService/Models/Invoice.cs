﻿using System;
/* *
* Author: Nisha Fadadu
* Cortex Test Project
* Titel : Invoice class
* Description : defines invoice properties 
* Date : 10th Sept 2017
* 
**/
namespace ParserService.Models
{
  
    public class Invoice
    {
        //invoice properties
        public string documentType;
        public string documentNumber;
        public string date;
        public string amount;
        public string currency;
       
    }
}