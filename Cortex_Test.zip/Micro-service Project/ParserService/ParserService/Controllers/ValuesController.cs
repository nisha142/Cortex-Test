﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using ParserService.Models;

/* *
 * Author: Nisha Fadadu
 * Cortex Test Project
 * Titel : Parser Microservice 
 * Description : ParserService is take json data from collector microservice and parsed the object return two objects
 * Date : 10th Sept 2017
 * 
 **/

namespace ParserService.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        // GET api/values
        [HttpGet]
        public string Get()
        {
            return "Parser service has been started.";
        }

        //get method
        [HttpGet("ParsedData")]
        public async Task<Tuple<List<Response>, List<Invoice>>> ParsedData()
        {
            List<Orders> orderList = new List<Orders>(); //input list object
            List<Response> responseList = new List<Response>(); //response list object
            List<Invoice> invoiceList = new List<Invoice>(); //invoice list object
            try
            {
                using (var client = new HttpClient()) // get data via conecting httpclient
                {
                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST Collector service using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("http://localhost:61141/api/values/ReadFile");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api   
                        var inputObj = Res.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the Employee list  
                        orderList = JsonConvert.DeserializeObject<List<Orders>>(inputObj);

                    }
                    foreach (Orders i in orderList)
                    {
                        //take orders object list and separate into Invoice and Response objects lists
                        Response res = new Response();
                        Invoice inv = new Invoice();
                        //get date into milliseconds
                        DateTime baseDate = new DateTime(1970, 1, 1);
                        TimeSpan diff = i.date - baseDate;
                        string date = diff.TotalMilliseconds.ToString();

                        if (i.responseNumber != null)
                        {
                            //Response object list
                            res.documentNumber = i.responseNumber;
                            res.amount = i.amount;
                            res.date = date;
                            res.originalDocumentNumber = i.originalInvoiceNumber;
                            res.status = i.status;
                            res.currency = i.currency;
                            res.documentType = "Response";
                            responseList.Add(res);
                        }
                        else
                        {
                            //Invoice object list
                            inv.documentNumber = i.invoiceNumber;
                            inv.amount = i.amount;
                            inv.date = date;
                            inv.currency = i.currency;
                            inv.documentType = "Invoice";
                            invoiceList.Add(inv);
                        }
                    }

                    //returning the Response and Invoice list  
                    return new Tuple<List<Response>, List<Invoice>>(responseList, invoiceList);
                }
            }
            catch (Exception ex)
            {
                throw ex; //"Something wrong with collector service. Please check make sure that the services are running."
            }


        }
    }
}
