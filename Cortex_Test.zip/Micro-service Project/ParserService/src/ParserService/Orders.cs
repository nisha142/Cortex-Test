﻿namespace ParserService.Controllers
{
    internal class Orders
    {
    }
}