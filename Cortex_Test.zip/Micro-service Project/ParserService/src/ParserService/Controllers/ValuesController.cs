﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net;

namespace ParserService.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {

        public IEnumerable<Orders> Get()
        {
            List<Orders> model;
            using (var client = new HttpClient())
            {
                var json = client.DownloadString("http://localhost:62287/api/values");
                var serializer = new JavaScriptSerializer();
                model = serializer.Deserialize<List<Orders>>(json);
                // TODO: do something with the model
            }
            return model;
        }
        public async Task<List<Orders>> GetSampleClassObjects()
        {
            List<Orders> SampleClassObjectsList = null;
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _accessToken);
                    var data = await client.GetAsync(string.Concat(_serviceAddress, "routeName"));
                    var jsonResponse = await data.Content.ReadAsStringAsync();
                    if (jsonResponse != null)
                        SampleClassObjectsList = JsonConvert.DeserializeObject<List<Orders>>(jsonResponse);
                    return SampleClassObjectsList;
                }
            }

            catch (WebException exception)
            {
                throw new WebException("An error has occurred while calling GetSampleClassObjects method: " + exception.Message);
            }
        }

        // GET api/values
        [HttpGet]
        public async Task<List<Orders>> GetParsedData()
        {
            string Baseurl = "http://localhost:61141/api/values";
            List<Orders> model = null;
            HttpClient client = new HttpClient();

            HttpResponseMessage response = await client.GetAsync("http://localhost:61141/api/values");
            response.EnsureSuccessStatusCode();
            string responseBody = await response.Content.ReadAsStringAsync();
            // Above three lines can be replaced with new helper method below
            // string responseBody = await client.GetStringAsync(uri);
            if (responseBody != null)
                model = JsonConvert.DeserializeObject<List<Orders>>(responseBody);
            return model;
            //return new Orders();
            ///Console.WriteLine(responseBody);

            //using (client)
            //{
                //var json = client.GetAsync("http://localhost:61141/api/values");
            
                //var serializer = new JavaScriptSerializer();
                //JsonConvert.DeserializeObject(json);
              //  model = JsonConvert.DeserializeObject<List<Orders>>(json);
            //    // TODO: do something with the model
            //}
            //return responseBody;
            //return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
