USE [master]
GO

/****** Object:  Database [Cortext_Test]    Script Date: 2017-09-10 9:45:11 PM ******/
CREATE DATABASE [Cortext_Test]
GO


USE [Cortext_Test]
GO

/****** Object:  Table [dbo].[Invoice]    Script Date: 2017-09-10 9:45:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Invoice](
	[documentType] [nvarchar](50) NULL,
	[documentNumber] [nvarchar](50) NULL,
	[date] [nvarchar](50) NULL,
	[amount] [nvarchar](50) NULL,
	[currency] [nvarchar](50) NULL
) ON [PRIMARY]

GO


USE [Cortext_Test]
GO

/****** Object:  Table [dbo].[Response]    Script Date: 2017-09-10 9:45:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Response](
	[documentType] [nvarchar](50) NULL,
	[documentNumber] [nvarchar](50) NULL,
	[originalDocumentNumber] [nvarchar](50) NULL,
	[status] [nvarchar](50) NULL,
	[date] [nvarchar](50) NULL,
	[amount] [nvarchar](50) NULL,
	[currency] [nvarchar](50) NULL
) ON [PRIMARY]

GO


